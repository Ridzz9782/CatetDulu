let transactions = JSON.parse(localStorage.getItem("transactions")) || [];

function saveData(){
    localStorage.setItem("transactions", JSON.stringify(transactions));
}

function formatRupiah(number){
    return "Rp " + number.toLocaleString("id-ID");
}

function updateUI(){

    const list = document.getElementById("transactionList");
    list.innerHTML = "";

    let income = 0;
    let expense = 0;

    transactions.forEach((item,index)=>{

        if(item.type === "income"){
            income += item.amount;
        }else{
            expense += item.amount;
        }

        const div = document.createElement("div");
        div.classList.add("transaction");

        div.innerHTML = `
            <div>
                <strong>${item.title}</strong><br>
                <small>${item.type === "income" ? "Pemasukan" : "Pengeluaran"}</small>
            </div>

            <div>
                <strong>
                    ${item.type === "income" ? "+" : "-"}
                    ${formatRupiah(item.amount)}
                </strong>
                <br>
                <button class="delete-btn" onclick="deleteTransaction(${index})">
                    Hapus
                </button>
            </div>
        `;

        list.appendChild(div);

    });

    const saldo = income - expense;

    document.getElementById("saldo").innerText = formatRupiah(saldo);
    document.getElementById("income").innerText = formatRupiah(income);
    document.getElementById("expense").innerText = formatRupiah(expense);

}

function addTransaction(){

    const title = document.getElementById("title").value;
    const amount = parseInt(document.getElementById("amount").value);
    const type = document.getElementById("type").value;

    if(title === "" || isNaN(amount)){
        alert("Isi data dulu.");
        return;
    }

    transactions.push({
        title,
        amount,
        type
    });

    saveData();
    updateUI();

    document.getElementById("title").value = "";
    document.getElementById("amount").value = "";

}

function deleteTransaction(index){

    transactions.splice(index,1);

    saveData();
    updateUI();

}

updateUI();
